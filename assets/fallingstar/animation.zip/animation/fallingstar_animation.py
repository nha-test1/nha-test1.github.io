import pygame
import random

pygame.init()
WIDTH, HEIGHT = 500, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))

# colors (rgb values)
WHITE = (255, 255, 255)
ORANGE = (255, 153, 51)
BLUE = (0, 0, 51)

# star setup
star_radius = 30
star_x = random.randint(5, WIDTH - 5)
star_y = 0
star_speed = 5

# game loop
while True:
    pygame.time.delay(30) # slow down loop for animation

    # event handling (close window)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    # move star downward
    star_y += star_speed

    # reset the star when it reaches the bottom
    if star_y > HEIGHT:
        star_y = 0 
        star_x = random.randint(5, WIDTH - 5)

    # draw everything
    screen.fill(BLUE)
    pygame.draw.circle(screen, ORANGE, (star_x, star_y), star_radius)

    # refresh the screen
    pygame.display.update()